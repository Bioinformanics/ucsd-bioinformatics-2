import itertools
